# -*- coding: utf-8 -*-
__author__ = "Roberto Arias"
__maintainer__ = "Asignatura Big Data - Taller OOP in Data Science"
__copyright__ = "Copyright 2022 - Asignatura Big Data"
__version__ = "0.0.8"


try:
    import pandas as pd
    import os
    import json
    import datetime
    from IPython.display import display
    from pathlib import Path as p
    import sweetviz  
    
except Exception as exc:
    print('Module(s) {} are missing.:'.format(str(exc)))



        
def describe_data_en_memoria(data):
    '''
    Presenta la descripción general del conjunto de datos. Asimismo, para las variables 
    numéricas presenta los principales estadísticos descriptivos.
    
    Parámetros
    ----------
    data: dataframe para analizar
    
    Retorna
    -------
    Dos dataframe una por cada tipo de variables cualitativa o cuantitativa con
    su descripción
    '''
    try:
        cuanti,cuali=lista_variables_por_tipo(data)
        if len(cuanti) > 1:
            data_cuanti = data[cuanti]
            cuanti_desc = data_cuanti.describe()
        if len(cuali) > 1:
            data_cuali = data[cuali]
            cuali_desc = data_cuali.describe()
        return cuanti_desc, cuali_desc
    except Exception as exc:
        mostrar_error(exc)


    
def lista_variables_por_tipo(data):
    '''
    Genera una lista por cada uno de los tipos de variables contenidas en el dataframe
    contenido en el atributo data de la clase.
    Identifica el formato y tipo de variable
    
    Parámetros
    ----------
    data: dataframe para analizar
    
    Retorna
    -------
    Dos listas una por cada tipo de variable, cualitativa y cuantitativa.
    '''
    d_type = []
    cuanti = []
    cuali = []   
    try:
        for col in data.columns.to_list():
            registros = data[col].to_list()
            d_type = []
            for i in range(len(registros)):
                d_type.append(type(registros[i]))
            ntype = set(d_type)
            if ntype == {float} or ntype == {int} or ntype == {datetime.datetime}:
                cuanti.append(col)
            if ntype == {str}:
                cuali.append(col)
        return cuanti, cuali
    except Exception as exc:
        mostrar_error(exc)
           
def muestra_data_en_pantalla(data,numero_filas = None):
    '''
    La función debe mostrar la cantidad de filas requeridas o el total de filas cuando
    no reciba el parámetro numero_filas.
    
    Parámetros
    -------
    numero_filas: int
        Descripción: cantidad de filas a visualizar
    
    Retorna
    -------  
    La visualización en pantalla de la cantidad de registros definidos de la data o la data completa     
        
    '''
    try:
        if numero_filas is not None:
            datanew=data.sample(numero_filas)
            display(datanew)
        else:
            display(data)
    except Exception as exc:
        mostrar_error(exc)       
    

    
def muestra_archivos(lst_files):
    '''
    Imprime en pantalla cada uno de los elementos contenidos en una lista de archivos.
    
    Parámetros
    -------
    lst_files: lista
        Descripción: lista de elementos a consultar
    
    Retorna
    -------
    Nombre de los archivos que se encuentran en la ruta del directorio seleccionado
    '''
    try:
        for ct,f in enumerate(lst_files):
            child = os.path.splitext(os.path.basename(f))[0]
            print('{}{} {}'.format('\t',ct,child))
        return child
    except Exception as exc:
        mostrar_error(exc)
        


def save(data, filename = None, tipo = None, path=None):
    '''
    Guarda los archivos según su tipo
    
    Parámetros
    --------
    data: dataframe
        Descripción: dataframe para analizar
    filename:str
        Descripción: Nombre con el que se quiere guardar el archivo
    tipo:str
        Descripción: Formato en el que se quiere guardar el archivo. 
        Las opciones son csv, json, parquet o xlsx. 
    path:str 
        Descripción: Ruta donde se quiere guardar el archivo creado 
        
    Return 
    --------
    Archivo guardado en la ruta de trabajo en formato csv, json, parquet o xlsx 
    '''
    
    try:
        if filename is not None and tipo is not None:           
            if tipo == 'xlsx':
                data.to_excel(filename+'.xlsx', sheet_name = 'sheet', index=False)  
            elif tipo == 'csv':
                rg = str(p(path) /str(filename))
                print(rg)
                data.to_csv(rg+'.csv', encoding="utf-8", index=False)
            elif tipo == 'parquet':
                data.to_parquet(filename+'.parquet')
            elif tipo == 'json':
                json.dumps(data._json, filename+'.json', ensure_ascii=True)         
            else:
                print()        
    except Exception as exc:
        mostrar_error(exc)
        

        
def mostrar_error(ex):
    '''
    Captura el tipo de error, su descripción y localización.

    Parámetros
    ----------
    ex : Object
        Exception generada por el sistema.

    Retorno
    -------
    None.

    '''
    trace = []
    tb = ex.__traceback__
    while tb is not None:
        trace.append({
                      "filename": tb.tb_frame.f_code.co_filename,
                      "name": tb.tb_frame.f_code.co_name,
                      "lineno": tb.tb_lineno
                      })
        
        tb = tb.tb_next
        
    print('{}Something went wrong:'.format(os.linesep))
    print('---type:{}'.format(str(type(ex).__name__)))
    print('---message:{}'.format(str(type(ex))))
    print('---trace:{}'.format(str(trace)))


def perfilamiento(path, data, filename):
    '''
    Genera un archivo que permite visualizar las características de las variables contenidas en la data;
    en otras palabras, genera el perfilamiento de la data.
    
    Parámetros
    --------
    path:str 
        Descripción: Ruta donde se quiere guardar el archivo generado
    data: dataframe
        Descripción: dataframe para analizar
    ruta_archivo:str
        Descripción: Nombre con el que se quiere guardar el archivo
        
    Return 
    --------
    Archivo guardado en la ruta de trabajo en formato csv, json, parquet o xlsx 
    '''
    
    try:

        ''' Crear perfil de los datos '''
        name_eda = 'EDA_' + filename + '.html'#str(os.path.splitext(os.path.basename(ruta_archivo))[0]) + '.html'
        path_eda = str(p(path) /'output'/'eda')
        if not os.path.exists(path_eda):
            os.makedirs(path_eda)     
        my_report = sweetviz.analyze(data)
        return my_report.show_html(str(p(path_eda)/str(name_eda)))
    except Exception as exc:
        mostrar_error(exc)
        
        

def find_type(df_col):
    '''
    Función que identifica el tipo de variable
    
    Parámetros
    --------
    df_col:lst
        Descripción: Columna del dataframe a evaluar
        
    Return 
    --------
    type_result: Formato de los datos identificados 
    '''
    
    try:
        d_type = []
        for i in range(len(df_col)):
            d_type.append(type(df_col[i]))
        type_result = set(d_type)
        return type_result
    except Exception as exc:
        mostrar_error(exc)
   
def visualizar_tipo_dato(data):
    '''
    Función que muestra el tipo de variable de las columnas de un dataframe
    
    Parámetros
    --------
    data: dataframe
        Descripción: dataframe para analizar
        
    Retorna 
    --------
    dftipo: Dataframe que contiene las columnas y el/los tipo(s) de dato(s) de cada columna  
    '''
    try:
        columna=[]
        tipo=[]
        for col in data.columns.to_list():
            columna.append(col)
            tipo.append(find_type(data[col].tolist()))
        
        datos = {'Columna': columna,
                'Tipo': tipo,
                }
        dftipo = pd.DataFrame(datos)
        return dftipo
    except Exception as exc:
        mostrar_error(exc)
