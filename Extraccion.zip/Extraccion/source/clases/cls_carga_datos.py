# -*- coding: utf-8 -*-
__author__ = "Mónica Quiroga y Érika Espinosa"
__maintainer__ = "Asignatura Big Data - ETL"
__copyright__ = "Copyright 2022 - Asignatura Big Data"
__version__ = "0.0.1"

try:
    import pandas as pd
    #import pyarrow
    import json
    import glob
    import os
    from pandas import json_normalize
    
    
except Exception as exc:
            print('Module(s) {} are missing.:'.format(str(exc)))
               

class carga_data(object):
    
    
    def __init__(self,u = None, path=None,tipo_archivo=None, val=None):
        '''
        Inicializador de la clase, se establecen los atributos de la clase.
        Parámetros
        ----------
        utils : float, obligatorio
            DESCRIPCIÓN: Primer valor ingresado para efectuar la operación. Por defecto es None.
        operando2 : float, obligatorio
            DESCRIPCIÓN: Segundo valor ingresado para efectuar la operación. Por defecto es None.
        utils : módulo
            Descripción: carga funciones adicionales creadas en set_utilidades
        path : string de la ruta
            Descripción: ruta desde dónde se está tratando de cargar los datos
        tipo_archivo : str
            Descripción: nombre de la extensión de archivo que se 
        data : dataframe
            Descripción: guarda los datos que se ingresan desde el archivo leído
        lista_de_archivo : lista
            Descripción: presenta una lista de los archivos que se leen
        estado : booleano
            Descripción: cambia de acuerdo a la validación de una operación para continuar
        '''
        self.utils = u
        self.tipo_archivo = tipo_archivo
        self.path = path
        self.data = None #cuando carga datos
        self.lista_de_archivos = None 
        self.estado = False #operacion correcta o incorrecta
        self.validar = val
        
    
    def crear_lista_de_archivos(self, mostrar_lista= False):
        '''
        Lista los archivo de un directorio según el tipo de archivo solicitado.

        Parámetros
        ----------
        path : string 
            Descripción: Ruta del directorio que contiene los archivos.
        tipo_archivo : string
            Extensión o tipo de archivo.

        Retorna
        -------
        Lista de archivos alojados en la ruta indicada, según el tipo de archivo especifícado

        '''
        try:
            self.lista_de_archivos = [f for f in glob.glob(str(self.path)+'/**/*.'+ self.tipo_archivo.lower(), recursive=True)]
            
            if mostrar_lista:
                print('{}Archivos tipo {}:'.format(os.linesep,self.tipo_archivo))
                self.utils.muestra_archivos(self.lista_de_archivos)
                
            self.estado = True
            
        except Exception as exc:
            self.estado = False
            self.utils.mostrar_error(exc)
                  
        
    def carga_data_en_memoria(self, the_path):
        '''
        Carga datos desde un archivo y los organiza en un dataframe de pandas.
        El dataframe resultante se debe asignar al atributo data de la clase.
        
        Parámetros
        ----------
        the_path : string
            Descripción: Ruta del directorio donde se quiere cargar el archivo.

        Retorna
        -------
        La variable data con los datos del archivo leído

        '''

        try:
            # Usar función que valida el tipo de archivo
            self.validar.valida_tipo_archivo(the_path)
            
            if self.validar.estado:
                if self.tipo_archivo == 'csv':
                    try:
                        self.data = pd.read_csv(the_path,encoding="utf-8")
                        self.estado = True
                        #self.summary[child] = 'True'
                    except:
                        self.data = pd.read_csv(the_path,encoding="ISO-8859-1")
                        self.estado = True
                        #self.summary[child] = 'True'                      
                elif self.tipo_archivo == 'json':
                    with open(the_path) as file_json:
                        self.data = json.load(file_json)
                        self.data = json_normalize(self.data)
                        #self.data = self.data[['user.id','user.name','user.location','full_text','entities.user_mentions']]
                    self.estado = True     
                elif self.tipo_archivo == 'parquet':
                    self.data =pd.read_parquet(the_path)
                    self.estado = True
                elif self.tipo_archivo == 'txt':
                    self.data =open(the_path, "r").read().lower()
                    self.estado = True    
                    
                else:
                    print('El tipo de archivo {} no es permitido'.format(self.tipo_archivo))
                    self.estado = False
                    
                    
            else:
                print('El tipo de archivo {} no es permitido'.format(self.tipo_archivo))
                self.estado = False
                
        except Exception as exc:
            self.estado = False
            #self.summary[child] = 'False'
            self.utils.mostrar_error(exc)
            
    
    def selecciona_variables(self,variables):
        '''
        selecciona las variables que se van a utilizar dada una lista de variables.
        El proceso debe validar que existan esas variables en el conjunto de datos. En
        caso de no estar presente alguna de las variables, debe reportarlo en pantalla.
        Parameters
        ----------
        variables: tipo lista
            DESCRIPTION: lista de las variables a comparar
        Returns
        -------
        lnew : Lista de variables que si existen en el conjunto de datos
        '''
        try:
            lnew=[]
            lno=[]
            col=self.data.columns
            for i in variables:
                if i in col:
                    lnew.append(i)
                else:
                    lno.append(i)
            if lno: 
                print('La(s) variable(s) {} no está(n) en la base de datos'.format(lno))
            new_data=self.data[lnew]
            return new_data
        except Exception as exc:
            self.utils.mostrar_error(exc)
            print('La(s) variable(s) {} no está(n) en la base de datos'.format(lno))
    
    
    
    def describe_data_en_memoria(self):
        '''
        Presenta la descripción general del conjunto de datos. Asimismo, para las variables 
        numéricas presenta los principales estadísticos descriptivos.
        
        Parámetros
        ----------
        data: dataframe para analizar
        
        Retorna
        -------
        Dos dataframe uno por cada tipo de variables cualitativa o cuantitativa con
        su descripción
        '''

        try:
            self.utils.describe_data_en_memoria(self.data)
        except Exception as exc:
            self.utils.mostrar_error(exc) 

        
    
    def lista_variables_por_tipo(self):

        '''
        Genera una lista por cada uno de los tipos de variables contenidas en el dataframe
        contenido en el atributo data de la clase.
        Identifica el formato y tipo de variable
        
        Parámetros
        ----------
        data: dataframe para analizar
        
        Retorna
        -------
        Dos listas una por cada tipo de variable, cualitativa y cuantitativa.
        '''
        try:
            self.utils.lista_variables_por_tipo(self.data)
        except Exception as exc:
            self.utils.mostrar_error(exc) 

    def archivos_paraleer(self,lista_de_archivos):
        '''
        Verificación de los archivos que se pueden leer
        
        Parámetros
        ----------
        data: dataframe para analizar
        
        Retorna
        -------
        Dos listas una por cada tipo de variable, cualitativa y cuantitativa.
        '''
        try:
            lst=[]
            print(lista_de_archivos)
            for indice in range(len(lista_de_archivos)):
                    
                #indice = 7
                ruta_archivo = lista_de_archivos[indice]
                
                self.carga_data_en_memoria(ruta_archivo)
                print(self.estado)
                if self.estado ==False:
                    child = os.path.splitext(os.path.basename(ruta_archivo))[0]
                    lst.append(child)
                    print("Los siguientes archivos no se pueden leer")       
                    print(lst)
        except Exception as exc:
            self.estado = False
            self.utils.mostrar_error(exc)