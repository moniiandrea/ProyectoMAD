# -*- coding: utf-8 -*-
__author__ = "Roberto Arias"
__maintainer__ = "Asignatura Big Data - Taller OOP in Data Science"
__copyright__ = "Copyright 2022 - Asignatura Big Data"
__version__ = "0.0.1"



try:
    import pandas as pd
    from texthero import preprocessing
    import texthero as hero
    import re
    import nltk
    from nltk.corpus import stopwords
    from textblob import TextBlob
    import time
    
except Exception as exc:
    print('Module(s) {} are missing.:'.format(str(exc)))



class transforma_data(object):
    
    def __init__(self, u=None, path=None, data=None, val=None):
        self.utils = u
        self.path = path
        self.validar = val
        self.data = data
        self.estado = False
        self.stop_words_nltk = set(stopwords.words('Spanish'))
        self.custom_pipeline = [preprocessing.fillna, 
                           preprocessing.lowercase,
                           preprocessing.remove_digits,
                           preprocessing.remove_punctuation,
                           preprocessing.remove_diacritics,
                           preprocessing.remove_whitespace]
        self.stop_words_nltk.update(['y','la','por','ser','para','los','gracias','si','no'])
           
    def remover_duplicados(self,data):
        '''
        Función que elimina los registros duplicados.

        Parámetros
        ----------
        data : dataframe
            Descripción: Dataframe a transformar
            
        Retorna
        -------
        Dataframe sin registros duplicados
        
        '''
        
        try:
            
            self.validar.validacion_duplicados(data)
            
            if self.validar.estado == True:
                data = data.drop_duplicates()
            return data
        except Exception as exc:
            self.utils.mostrar_error(exc)
    
    def clean_text(self,text):
        '''
        Función que realiza la limpieza de texto.

        Parámetros
        ----------
        text : Serie
            Descripción: Columna de texto a la que se ejecutará la limpieza
            
        Retorna
        -------
        Texto con la limpieza aplicada
        
        '''

        try:            
            text = re.sub(r'^RT[\s]+', '', text)
            text = re.sub(r'https?:\/\/.*[\r\n]*', '', text)
            text = re.sub(r'#', '', text)
            text = re.sub(r'@[A-Za-z0-9]+', '', text)
            return text
        except Exception as exc:
            self.utils.mostrar_error(exc)     
           
    def polaridad(self,text):
        '''
        Calcula la polaridad de cada texto
        
        Parámetros
        ----------
        text : Serie
            Descripción: Columna de texto a la que se evaluará la polaridad
            
        Retorna
        -------
        Resultados de la polaridad
        
        '''
        try:
            analysis = TextBlob(text)
            if text != '':
              if analysis.detect_language() == 'es':
                result = analysis.translate(from_lang = 'es', to = 'en').sentiment.polarity
                time.sleep(5)
                return result
            #self.estado = True
        except Exception as exc:
            #self.estado = False
            self.utils.mostrar_error(exc)