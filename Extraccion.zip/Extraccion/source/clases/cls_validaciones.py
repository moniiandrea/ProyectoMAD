# -*- coding: utf-8 -*-
__author__ = "Roberto Arias"
__maintainer__ = "Asignatura Big Data - Taller OOP in Data Science"
__copyright__ = "Copyright 2022 - Asignatura Big Data"
__version__ = "0.0.1"


try:
    import pandas as pd
    import numpy as np
    import os
    import chardet
    import tweepy as tw
    
except Exception as exc:
    print('Module(s) {} are missing.:'.format(str(exc)))


class valida_data(object):
    
    
    def __init__(self,u = None):
        '''
        Inicializador de la clase, se establecen los atributos de la clase.
        
        Parámetros
        ----------
        utils : módulo
            Descripción: carga funciones adicionales creadas en set_utilidades
        estado : booleano
            Descripción: cambia de acuerdo a la validación de una operación para continuar
        '''
        self.utils = u
        self.estado = False
        
        
        
    def ds_is_empty(self):
        '''
        Valida si el dataframe está vacío.
      
        Parámetros
        ----------
        None.

        Retorna
        -------
        Estado True si el dataframe no está vacío o False de lo contrario. 
        '''
        
        try:
            if self.data.empty is not True:
                self.estado = True
            else:
                self.estado = False
        
        except Exception as exc:
            self.estado = False
            self.utils.mostrar_error(exc)
            
    def validar_path(self):
        '''
        Valida que exista el path desde dónde se está tratando de cargar los datos. 
        En caso que el path no exista, se debe terminar el proceso y reportar el error.
      
        Parámetros
        ----------
        None.

        Retorna
        -------
        Estado True si el path existe o False de lo contrario. 


        ''' 
        try:
            if os.path.exists(self.path):
               self.estado = True      
        except Exception as exc:
            self.estado = False
            self.utils.mostrar_error(exc)     
     
    def valida_tipo_archivo(self, path):
        '''
        Valida que el formato del archivo que se está leyendo está dentro de los permitidos; 
        en caso que no, debe terminar el proceso.
        Los archivo permitidos son: csv, json, parquet y txt.
      
        Parámetros
        ----------
        path : string
            Descripción: Ruta del archivo que se quiere cargar.

        Retorna
        -------
        Estado True si el formato del archivo es permitido o False de lo contrario. 

        '''
        root,extension=os.path.splitext(path)
        
        try:
            if extension[1:] in ['csv', 'json', 'parquet','txt']:         
                self.estado = True
                
        except Exception as exc:
            self.estado = False
            self.utils.mostrar_error(exc)
        
    def cantidad_registros(self):
        '''
        Permite validar que la cantidad de registros no sea inferior al 50% de la cantidad inicial de registros
    
        Parámetros
        ----------
        None.

        Retorna
        -------
        Estado True si la cantidad de registros de la data resultante de las transformaciones es mayor o igual al 50% de la cantidad de registros de la data inicial
        o False de lo contrario.           
           
        '''

        try:
            if len(self.data_new) >= len(self.data)*0.5:
                self.estado=True
                
        except Exception as exc:
            self.estado = False
            self.utils.mostrar_error(exc)
         
        
    def validacion_nulo(self, data): 
        ''' 
        Valida si el archivo cuenta con datos nulos e imprime en pantalla
        la cantidad de nulos que tiene cada variable
        
        Parámetros
        ----------
        data: Dataframe
            Descripción: Dataframe que se quiere validar 

        Retorna
        -------
        Estado True si el dataframe no contiene datos nulos
        o False de lo contrario, y mensaje respectivo.           

        '''
        
        try:
            if data.isnull().values.sum() == 0:
                print("No hay datos nulos en todo el dataframe")
                self.estado = True
            else:
                print("Hay",data.isnull().values.sum(), "datos nulos en todo el dataframe")
                print(data.isna().sum())  
                self.estado = False
        
        except Exception as exc:
            self.estado = False
            self.utils.mostrar_error(exc)

            
    def validacion_duplicados(self, data):
        '''
        Valida si el dataframe contiene datos duplicados
    
        Parámetros
        ----------
        data: Dataframe
            Descripción: Dataframe que se quiere validar 

        Retorna
        -------
        Estado True si el dataframe contiene registros duplicados
        o False de lo contrario.           


        '''
        try:
            self.duplicados = data.duplicated()
            self.unicos = self.duplicados.unique()
            #print(self.unicos)
            for i in range(len(self.unicos)):  
                if self.unicos[i] == True:
                    self.estado = True
        except Exception as exc:
            self.estado = False
            self.utils.mostrar_error(exc)
    
    def valida_vacios(self,text):

        '''
        Valida si el campo es vacio
    
        Parámetros
        ----------
        text: Serie
            Descripción: Columna que se quiere validar 

        Retorna
        -------
        Estado True si el campo no es vacio
        o False de lo contrario.           

        '''
        try:
            if not text.isnull():
                self.estado = True
        except Exception as exc:
            self.estado = False
            self.utils.mostrar_error(exc)

            
    def valida_multi_tipo(self):
        '''
        Validar que los registros de la columna tengan todos el mismo formato.
           
        Parámetros
        ----------
        None. 

        Retorna
        -------
        Estado True si todas las columnas tienen un único formato
        o False de lo contrario, también se incluye un mensaje indicando las columnas con múltiples formatos.           

        '''
        
        try:
            multi=[]
            for col in self.data:
                if len(self.utils.find_type(self.data[col].to_list()))==1:
                    self.estado = True 
                else:
                    multi.append(col) 
            if len(multi)>0:
                print('Las columnas con múltiples tipos de datos son: {}'.format(multi))
                self.estado=False
            else:
                print('Las columnas no tienen múltiples tipos de datos')
  
        except Exception as exc:
            self.estado = False
            self.utils.mostrar_error(exc)  

    def valida_alta_correlacion(self,data):
        '''
        Validar que la data no contenga dos columnas altamente correlacionadas.
        Calcula el coeficiente de correlación de Spearman y si el valor es mayor o 0.9 o menor a -0.9 para dos variables distintas, 
        el estado pasa a False dado que las variables están altamente correlacionadas, ya sea positiva o negativamente.
        
        Parámetros
        ----------
        data: Dataframe
            Descripción: Dataframe que se quiere validar 

        Retorna
        -------
        Estado True si las columnas no tienen una alta correlación
        o False de lo contrario.

        '''
        
        try:
            correla=self.data.corr(method='spearman')
            for col in correla:
                for idx,row in correla.iterrows():
                    if idx!=col:
                        if row[col]<0.9 and row[col]>-0.9:
                            self.estado=True
        except Exception as exc:
            self.estado = False
            self.utils.mostrar_error(exc)    
   
    def validacion_cant_nulos(self): 
        ''' 
        Validar que la columna no contenga más del 40% de datos nulos o faltantes.
        
        Parámetros
        ----------
        None.
        
        Retorna
        -------
        Estado True si las columnas no tienen más del 40% de datos nulos o faltante
        o False de lo contrario, más un mensaje indicando las columnas que presentan
        más del 40% de los registros faltantes.

        '''
        
        try:
            nulos=self.data.isna().sum()
            colum2=[]
            for index,value in nulos.items():
                if value<=len(self.data)*0.4:
                    self.estado=True
                else:
                    self.estado=False
                    colum2.append(index)
           
            if self.estado==False:
                print('Las columnas con más del 40% de faltantes son: {}'.format(colum2))
                   
        except Exception as exc:
            self.estado = False
            self.utils.mostrar_error(exc)
            
    def acceso(self,my_api_key, my_api_secret):
        '''
        Validar el acceso al API de Twitter.
        
        Parámetros
        ----------
        my_api_key: strig
            Descripción: Clave para acceder al API de Twitter
        my_api_secret: strig
            Descripción: Clave secreta para acceder al API de Twitter

        Retorna
        -------
        Estado True si se puede acceder al API
        o False de lo contrario.

        '''
        try:
            self.auth = tw.OAuthHandler(my_api_key, my_api_secret)
            self.estado=True
        except Exception as exc:
            self.estado = False
            self.utils.mostrar_error(exc)

