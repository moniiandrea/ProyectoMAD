# -*- coding: utf-8 -*-
__author__ = "Mónica Quiroga, Érika Espinosa y Karla Rodriguez"
__maintainer__ = "Proyecto MAD"
__copyright__ = "Copyright 2022 - Proyecto MAD"
__version__ = "0.0.1"

try:
    ''' Librerías estandar de Python '''
    import os,sys
    from pathlib import Path as p
    import pandas as pd
    import tweepy
    import json
    from datetime import date
    import time
    

except Exception as exc:
    print('Module(s) {} are missing.:'.format(str(exc)))

today = date.today()
dir_root = p(__file__).parents[0]
sys.path.append(str(p(dir_root) /'source' / 'clases'))
sys.path.append(str(p(dir_root) /'source' / 'utilidades'))
''' Conjunto de utilidades '''
import set_utilidades as ut
from cls_carga_datos import carga_data
''' Clase para validaciones '''
from cls_validaciones import valida_data

''' Crear una instancia de la clase '''
val = valida_data(u = ut)
'''Revisar la existencia de la carpeta donde se guardan los archivos'''
path_data = str(p(dir_root) / 'Dataset' / 'Twitter')
if not os.path.exists(path_data):
    os.makedirs(path_data)

ld_Tw = carga_data(path = dir_root,u = ut,val=val)
ld_Tw.tipo_archivo = 'json'
ld_Tw.path = path_data

#%%
'''Acceso a Twitter'''
my_api_key = 'clave'
my_api_secret = 'clave'

auth = tweepy.OAuth1UserHandler(my_api_key, my_api_secret)
#auth.set_access_token(access_token, access_token_secret)
# con este objeto realizaremos todas las llamadas al API
api = tweepy.API(auth,wait_on_rate_limit=True)

#%%
Lote = str(p(dir_root)/ 'Dataset' / 'Twitter'/'Revision4')
if not os.path.exists(Lote):
    os.makedirs(Lote)
#%%

path_day = str(p(Lote)/str(today))
if not os.path.exists(path_day):
    os.makedirs(path_day)

#%%
'''Extracción de Tweets sector'''
lst = ['Ucentral -filter:retweets',
       'UCentralBogota -filter:retweets',
        'EgresadosCentralistas -filter:retweets',
        'OrgulloCentralista -filter:retweets',
        'SENAComunica -filter:retweets',
        'YoSoyCUN -filter:retweets',
        'udistrital -filter:retweets',
        'Unimagdalena -filter:retweets',
        'Unidades_UTS -filter:retweets',
        'lamilitar -filter:retweets',
        'Uniquindio -filter:retweets',
        'udes_oficial -filter:retweets',
        'USCOoficial -filter:retweets',
        'tecdeantioquia -filter:retweets',
        'udecaldas -filter:retweets',
        'USergioArboleda -filter:retweets',
        'ULaGranColombia -filter:retweets',
        'UdeMedellin_ -filter:retweets',
        'Ucompensar -filter:retweets',
        'TComfenalco -filter:retweets',
        'Unisucre -filter:retweets',
        'utboficial -filter:retweets',
        'USanMartinCO -filter:retweets',
        'UniagustOficial -filter:retweets',
        'ceipabs -filter:retweets',
        'UpilotoOficial -filter:retweets',
        'uantonionarino -filter:retweets',
        'UniversidadUNAD -filter:retweets',
        'Areandina -filter:retweets',
        'ITMinstitucion -filter:retweets',
        'Unipamplona -filter:retweets',
        'UIS -filter:retweets',
        'UTPereira -filter:retweets',
        'Unicordoba_Col -filter:retweets',
        'LaIberoU_ -filter:retweets',
        'UniLaGuajira -filter:retweets',
        'USBCali -filter:retweets',
        'UExternado -filter:retweets',
        'americana_med -filter:retweets',
        'unab_online -filter:retweets',
        'UniCecar -filter:retweets',
        'umanizales -filter:retweets',
        'UniversidadCES -filter:retweets',
        'UMarianaPasto -filter:retweets',
        'IUColmayor -filter:retweets',
        'Escuelaing -filter:retweets',
        'Unicolmayorcund -filter:retweets',
        'IUDIGITAL -filter:retweets',
        'unisalle -filter:retweets',
        'UCatolicaCo -filter:retweets',
        'UNIMINUTOCOL -filter:retweets',
        'UnivalleCol -filter:retweets',
        'Unilibrebog -filter:retweets',
        'Uni_Tolima -filter:retweets',
        'ESAPOficial -filter:retweets',
        'unicauca -filter:retweets',
        'Unipopularcesar -filter:retweets',
        'RadioUdenar -filter:retweets',
        'PrensaUTCH -filter:retweets',
        'UCundinamarca -filter:retweets',
        'PolitecnicoJIC -filter:retweets',
        'uni_cartagena -filter:retweets',
        'comunidadUPN -filter:retweets',
        'lauao -filter:retweets',
        'UniLibertadores -filter:retweets',
        'UMBBUCARAMANGA -filter:retweets',
        'La_Fup -filter:retweets',
        'URepublicana_ -filter:retweets',
        'USanMartinCO -filter:retweets',
        'UniCostaCOL -filter:retweets',
        'usta_colombia -filter:retweets',
        'UniversidadECCI -filter:retweets',
        'areandina -filter:retweets',
        'UCooperativaCol -filter:retweets',
        'UdeA -filter:retweets',
        'UFPSCUCUTA -filter:retweets',
        'upbcolombia -filter:retweets',
        'usantiagodecali -filter:retweets',
        'UNALOficial -filter:retweets',
        'unisimon -filter:retweets',
        'uluisamigo -filter:retweets',
        'UnisinuOficial -filter:retweets',
        'URosario -filter:retweets',
        'U_ElBosque -filter:retweets',
        'UNIAJC -filter:retweets',
        'uniamazonia -filter:retweets',
        'IUPascualBravo -filter:retweets',
        'Utadeo_edu_co -filter:retweets',
        'unillanos_ -filter:retweets',
        'unicesmag -filter:retweets',
        'UniAsturias -filter:retweets',
        'Escuelaing -filter:retweets',
        'universidaduptc -filter:retweets',
        'Uni_Remington -filter:retweets',
        'uniandes -filter:retweets',
        'UninorteCO -filter:retweets',
        'unisabana -filter:retweets',
        'EAFIT -filter:retweets',
        'icesi -filter:retweets',
        'InfoUDI -filter:retweets',
        'UAutonoma -filter:retweets',
        'UniversidadEan -filter:retweets',
        'poligran -filter:retweets',
        'uexternado -filter:retweets',
        'poligran -filter:retweets',
        'uexternado -filter:retweets']

compe = ['Ucentral',
        'UCentralBogota',
        'EgresadosCentralistas',
        'OrgulloCentralista',
        'SENAComunica',
        'YoSoyCUN',
        'udistrital',
        'Unimagdalena',
        'Unidades_UTS',
        'lamilitar',
        'Uniquindio',
        'udes_oficial',
        'USCOoficial',
        'tecdeantioquia',
        'udecaldas',
        'USergioArboleda',
        'ULaGranColombia',
        'UdeMedellin_',
        'Ucompensar',
        'TComfenalco',
        'Unisucre',
        'utboficial',
        'USanMartinCO',
        'UniagustOficial',
        'ceipabs',
        'UpilotoOficial',
        'uantonionarino',
        'UniversidadUNAD',
        'Areandina',
        'ITMinstitucion',
        'Unipamplona',
        'UIS',
        'UTPereira',
        'Unicordoba_Col',
        'LaIberoU_',
        'UniLaGuajira',
        'USBCali',
        'UExternado',
        'americana_med',
        'unab_online',
        'UniCecar',
        'umanizales',
        'UniversidadCES',
        'UMarianaPasto',
        'IUColmayor',
        'Escuelaing',
        'Unicolmayorcund',
        'IUDIGITAL',
        'unisalle',
        'UCatolicaCo',
        'UNIMINUTOCOL',
        'UnivalleCol',
        'Unilibrebog',
        'Uni_Tolima',
        'ESAPOficial',
        'unicauca',
        'Unipopularcesar',
        'RadioUdenar',
        'PrensaUTCH',
        'UCundinamarca',
        'PolitecnicoJIC',
        'uni_cartagena',
        'comunidadUPN',
        'lauao',
        'UniLibertadores',
        'UMBBUCARAMANGA',
        'La_Fup',
        'URepublicana_',
        'USanMartinCO',
        'UniCostaCOL',
        'usta_colombia',
        'UniversidadECCI',
        'areandina',
        'UCooperativaCol',
        'UdeA',
        'UFPSCUCUTA',
        'upbcolombia',
        'usantiagodecali',
        'UNALOficial',
        'unisimon',
        'uluisamigo',
        'UnisinuOficial',
        'URosario',
        'U_ElBosque',
        'UNIAJC',
        'uniamazonia',
        'IUPascualBravo',
        'Utadeo_edu_co',
        'unillanos_',
        'unicesmag',
        'UniAsturias',
        'Escuelaing',
        'universidaduptc',
        'Uni_Remington',
        'uniandes',
        'UninorteCO',
        'unisabana',
        'EAFIT',
        'icesi',
        'InfoUDI',
        'UAutonoma',
        'UniversidadEan',
        'poligran',
        'uexternado',
        'poligran',
        'uexternado']

j = 0

for i in lst:
    search_query=i
    nombre=str(compe[j])+str(today)
    j = j + 1
    '''Usar el API para buscar'''
    tweets = tweepy.Cursor(api.search_tweets,q=search_query,lang="es",
                       tweet_mode="extended", result_type='mixed ').items(1500)
    '''Guardar los tweets en una lista'''
    tweets_json=[]
    for tweet in tweets:
       tweets_json.append(tweet._json)
    '''Guardar los tweets en formato json''' 
    rg = str(p(path_day) /str(nombre)) #ruta mas el nombre con el que se guarda el archivo
    s = json.dumps(tweets_json, indent=4) #convertir un diccionario en str
    f = open(rg+'.json', 'w') #Crear archivo json
    f.write(s) #Escribir el str dentro del archivo json
    f.close()
    time.sleep(15)
    
#%%
'''Genericas relacionadas con el sector'''
lst = ['universidad AND colombia OR universidades AND colombia -filter:retweets',
       'Educación superior AND colombia -filter:retweets']

nombre_lst = ['universidad_colombia','educacionsuperior_colombia']
j = 0

for i in lst:
    search_query=i
    nombre=str(nombre_lst[j])+str(today)
    j = j + 1
    '''Usar el API para buscar'''
    tweets = tweepy.Cursor(api.search_tweets,q=search_query,lang="es",
                       tweet_mode="extended", result_type='mixed ').items(1000)
    '''Guardar los tweets en una lista'''
    tweets_json=[]
    for tweet in tweets:
       tweets_json.append(tweet._json)
    '''Guardar los tweets en formato json''' 
    rg = str(p(path_day) /str(nombre)) #ruta mas el nombre con el que se guarda el archivo
    s = json.dumps(tweets_json, indent=4) #convertir un diccionario en str
    f = open(rg+'.json', 'w') #Crear archivo json
    f.write(s) #Escribir el str dentro del archivo json
    f.close()
    time.sleep(15)
#para el preprocesamiento tener en cuenta las localizaciones

#%%

Lote = str(p(dir_root)/ 'Dataset' / 'Twitter')

ld_Tw = carga_data(path = dir_root,u = ut,val=val)
ld_Tw.tipo_archivo = 'json'
ld_Tw.path = Lote

#%%
'''Para verificar la lectura de los archivos Json y poder verificar la cantidad de tweets recolectados'''
ld_Tw.crear_lista_de_archivos(mostrar_lista = True)
'''Archivos que se pueden leer'''
ld_Tw.archivos_paraleer(ld_Tw.lista_de_archivos)
'''Cargar data en memoria'''
dfg = []
for indice in range(len(ld_Tw.lista_de_archivos)):
    ruta_archivo = ld_Tw.lista_de_archivos[indice]
    ld_Tw.carga_data_en_memoria(ruta_archivo)
    #Crear la columna a partir de data "Query" nombre del archivo
    ld_Tw.data['Query'] = ruta_archivo.split("\\")[10] #[11]
    globals()["df" + str(indice)] = ld_Tw.data
    dfg.append(globals()["df" + str(indice)])
'''Unir los dataframes'''
nueva = pd.concat(dfg,axis=0)

#%%
frame = nueva[['created_at','user.id','user.name','user.location','full_text','entities.user_mentions','Query']]

df = frame.drop_duplicates(['full_text'], keep='first')

#%%
drt = df.copy()
drt = drt[~drt['full_text'].str.contains('RT')]

#%%

print("nueva",nueva.shape)
print("frame",frame.shape)
print("df",df.shape)
print("drt",drt.shape)
#%%
'''Guardar en CSV'''
path_d = str(p(dir_root) / 'Dataset')
ut.save(data=drt,path=path_d,tipo='csv',filename='Tweets_Lote_1y2')

